--
-- PostgreSQL database dump
--

\restrict uup1ieCnGictJenlzSh5bK7Qd6GwXshvLV0WcWgQB8UJV2wMbuseFTXDKEBX92u

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.purchase_exceptions DROP CONSTRAINT IF EXISTS purchase_exceptions_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_brand_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_units DROP CONSTRAINT IF EXISTS product_units_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_units DROP CONSTRAINT IF EXISTS product_units_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_units DROP CONSTRAINT IF EXISTS product_units_parent_unit_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_assembly_templates DROP CONSTRAINT IF EXISTS product_assembly_templates_parent_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_assembly_templates DROP CONSTRAINT IF EXISTS product_assembly_templates_child_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pending_sales DROP CONSTRAINT IF EXISTS pending_sales_resolved_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pending_sales DROP CONSTRAINT IF EXISTS pending_sales_cash_day_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cash_events DROP CONSTRAINT IF EXISTS cash_events_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cash_events DROP CONSTRAINT IF EXISTS cash_events_cash_day_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cash_event_items DROP CONSTRAINT IF EXISTS cash_event_items_product_unit_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cash_event_items DROP CONSTRAINT IF EXISTS cash_event_items_cash_event_id_fkey;
DROP INDEX IF EXISTS public.ix_suppliers_name;
DROP INDEX IF EXISTS public.ix_purchase_rules_id;
DROP INDEX IF EXISTS public.ix_purchase_exceptions_id;
DROP INDEX IF EXISTS public.ix_products_code;
DROP INDEX IF EXISTS public.ix_product_units_unique_serial_number;
DROP INDEX IF EXISTS public.ix_customers_phone;
DROP INDEX IF EXISTS public.ix_customers_name;
DROP INDEX IF EXISTS public.ix_cash_days_date;
DROP INDEX IF EXISTS public.ix_brands_name;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_rules DROP CONSTRAINT IF EXISTS purchase_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_exceptions DROP CONSTRAINT IF EXISTS purchase_exceptions_product_id_key;
ALTER TABLE IF EXISTS ONLY public.purchase_exceptions DROP CONSTRAINT IF EXISTS purchase_exceptions_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.product_units DROP CONSTRAINT IF EXISTS product_units_pkey;
ALTER TABLE IF EXISTS ONLY public.product_assembly_templates DROP CONSTRAINT IF EXISTS product_assembly_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.pending_sales DROP CONSTRAINT IF EXISTS pending_sales_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.cash_events DROP CONSTRAINT IF EXISTS cash_events_pkey;
ALTER TABLE IF EXISTS ONLY public.cash_event_items DROP CONSTRAINT IF EXISTS cash_event_items_pkey;
ALTER TABLE IF EXISTS ONLY public.cash_days DROP CONSTRAINT IF EXISTS cash_days_pkey;
ALTER TABLE IF EXISTS ONLY public.brands DROP CONSTRAINT IF EXISTS brands_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.suppliers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.purchase_rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.purchase_exceptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_units ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_assembly_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pending_sales ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cash_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cash_event_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cash_days ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.brands ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.suppliers_id_seq;
DROP TABLE IF EXISTS public.suppliers;
DROP SEQUENCE IF EXISTS public.purchase_rules_id_seq;
DROP TABLE IF EXISTS public.purchase_rules;
DROP SEQUENCE IF EXISTS public.purchase_exceptions_id_seq;
DROP TABLE IF EXISTS public.purchase_exceptions;
DROP SEQUENCE IF EXISTS public.products_id_seq;
DROP TABLE IF EXISTS public.products;
DROP SEQUENCE IF EXISTS public.product_units_id_seq;
DROP TABLE IF EXISTS public.product_units;
DROP SEQUENCE IF EXISTS public.product_assembly_templates_id_seq;
DROP TABLE IF EXISTS public.product_assembly_templates;
DROP SEQUENCE IF EXISTS public.pending_sales_id_seq;
DROP TABLE IF EXISTS public.pending_sales;
DROP SEQUENCE IF EXISTS public.customers_id_seq;
DROP TABLE IF EXISTS public.customers;
DROP SEQUENCE IF EXISTS public.categories_id_seq;
DROP TABLE IF EXISTS public.categories;
DROP SEQUENCE IF EXISTS public.cash_events_id_seq;
DROP TABLE IF EXISTS public.cash_events;
DROP SEQUENCE IF EXISTS public.cash_event_items_id_seq;
DROP TABLE IF EXISTS public.cash_event_items;
DROP SEQUENCE IF EXISTS public.cash_days_id_seq;
DROP TABLE IF EXISTS public.cash_days;
DROP SEQUENCE IF EXISTS public.brands_id_seq;
DROP TABLE IF EXISTS public.brands;
DROP TABLE IF EXISTS public.alembic_version;
DROP TYPE IF EXISTS public.physicalstatus;
DROP TYPE IF EXISTS public.pendingstatus;
DROP TYPE IF EXISTS public.logisticsstatus;
DROP TYPE IF EXISTS public.casheventtype;
--
-- Name: casheventtype; Type: TYPE; Schema: public; Owner: crm_admin
--

CREATE TYPE public.casheventtype AS ENUM (
    'SALE',
    'RETURN',
    'INCOME',
    'EXPENSE'
);


ALTER TYPE public.casheventtype OWNER TO crm_admin;

--
-- Name: logisticsstatus; Type: TYPE; Schema: public; Owner: crm_admin
--

CREATE TYPE public.logisticsstatus AS ENUM (
    'CANDIDATE',
    'IN_REQUEST',
    'IN_DELIVERY',
    'RECEIVED'
);


ALTER TYPE public.logisticsstatus OWNER TO crm_admin;

--
-- Name: pendingstatus; Type: TYPE; Schema: public; Owner: crm_admin
--

CREATE TYPE public.pendingstatus AS ENUM (
    'PENDING',
    'RESOLVED',
    'CANCELLED'
);


ALTER TYPE public.pendingstatus OWNER TO crm_admin;

--
-- Name: physicalstatus; Type: TYPE; Schema: public; Owner: crm_admin
--

CREATE TYPE public.physicalstatus AS ENUM (
    'IN_STORE',
    'SOLD',
    'LOST',
    'WRITE_OFF',
    'IN_DISASSEMBLED',
    'ABSORBED',
    'EXPECTED'
);


ALTER TYPE public.physicalstatus OWNER TO crm_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO crm_admin;

--
-- Name: brands; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.brands (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.brands OWNER TO crm_admin;

--
-- Name: brands_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.brands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.brands_id_seq OWNER TO crm_admin;

--
-- Name: brands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.brands_id_seq OWNED BY public.brands.id;


--
-- Name: cash_days; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.cash_days (
    id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    is_closed boolean NOT NULL,
    total_revenue numeric(10,2) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.cash_days OWNER TO crm_admin;

--
-- Name: cash_days_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.cash_days_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_days_id_seq OWNER TO crm_admin;

--
-- Name: cash_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.cash_days_id_seq OWNED BY public.cash_days.id;


--
-- Name: cash_event_items; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.cash_event_items (
    id integer NOT NULL,
    cash_event_id integer NOT NULL,
    product_unit_id integer NOT NULL,
    price_per_unit numeric(10,2) NOT NULL,
    discount_amount numeric(10,2) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.cash_event_items OWNER TO crm_admin;

--
-- Name: cash_event_items_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.cash_event_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_event_items_id_seq OWNER TO crm_admin;

--
-- Name: cash_event_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.cash_event_items_id_seq OWNED BY public.cash_event_items.id;


--
-- Name: cash_events; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.cash_events (
    id integer NOT NULL,
    cash_day_id integer NOT NULL,
    customer_id integer,
    type public.casheventtype NOT NULL,
    total_amount numeric(10,2) NOT NULL,
    amount_cash numeric(10,2) NOT NULL,
    amount_card numeric(10,2) NOT NULL,
    amount_credit numeric(10,2) NOT NULL,
    description character varying(255),
    created_by character varying(100) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.cash_events OWNER TO crm_admin;

--
-- Name: cash_events_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.cash_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cash_events_id_seq OWNER TO crm_admin;

--
-- Name: cash_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.cash_events_id_seq OWNED BY public.cash_events.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    parent_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO crm_admin;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO crm_admin;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    phone character varying(20),
    email character varying(100),
    balance numeric(10,2) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.customers OWNER TO crm_admin;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO crm_admin;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: pending_sales; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.pending_sales (
    id integer NOT NULL,
    cash_day_id integer NOT NULL,
    temp_name character varying(255) NOT NULL,
    temp_price numeric(10,2) NOT NULL,
    temp_quantity integer NOT NULL,
    temp_category_name character varying(100),
    temp_brand_name character varying(100),
    status public.pendingstatus NOT NULL,
    resolved_product_id integer,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.pending_sales OWNER TO crm_admin;

--
-- Name: pending_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.pending_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pending_sales_id_seq OWNER TO crm_admin;

--
-- Name: pending_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.pending_sales_id_seq OWNED BY public.pending_sales.id;


--
-- Name: product_assembly_templates; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.product_assembly_templates (
    id integer NOT NULL,
    parent_product_id integer NOT NULL,
    child_product_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.product_assembly_templates OWNER TO crm_admin;

--
-- Name: product_assembly_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.product_assembly_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_assembly_templates_id_seq OWNER TO crm_admin;

--
-- Name: product_assembly_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.product_assembly_templates_id_seq OWNED BY public.product_assembly_templates.id;


--
-- Name: product_units; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.product_units (
    id integer NOT NULL,
    product_id integer NOT NULL,
    supplier_id integer,
    unique_serial_number character varying(100) NOT NULL,
    purchase_price numeric(10,2),
    logistics_status public.logisticsstatus NOT NULL,
    physical_status public.physicalstatus NOT NULL,
    is_reserved boolean NOT NULL,
    parent_unit_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.product_units OWNER TO crm_admin;

--
-- Name: product_units_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.product_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_units_id_seq OWNER TO crm_admin;

--
-- Name: product_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.product_units_id_seq OWNED BY public.product_units.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.products (
    id integer NOT NULL,
    category_id integer NOT NULL,
    brand_id integer,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(1000),
    recommended_retail_price numeric(10,2),
    search_tags jsonb,
    search_aliases jsonb,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    images jsonb
);


ALTER TABLE public.products OWNER TO crm_admin;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO crm_admin;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: purchase_exceptions; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.purchase_exceptions (
    id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.purchase_exceptions OWNER TO crm_admin;

--
-- Name: purchase_exceptions_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.purchase_exceptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_exceptions_id_seq OWNER TO crm_admin;

--
-- Name: purchase_exceptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.purchase_exceptions_id_seq OWNED BY public.purchase_exceptions.id;


--
-- Name: purchase_rules; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.purchase_rules (
    id integer NOT NULL,
    price_operator character varying(50),
    price_value numeric(10,2),
    name_contains character varying(255),
    stock_threshold integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.purchase_rules OWNER TO crm_admin;

--
-- Name: purchase_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.purchase_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_rules_id_seq OWNER TO crm_admin;

--
-- Name: purchase_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.purchase_rules_id_seq OWNED BY public.purchase_rules.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: crm_admin
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    contact_info character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.suppliers OWNER TO crm_admin;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_admin
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_id_seq OWNER TO crm_admin;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_admin
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: brands id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.brands ALTER COLUMN id SET DEFAULT nextval('public.brands_id_seq'::regclass);


--
-- Name: cash_days id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_days ALTER COLUMN id SET DEFAULT nextval('public.cash_days_id_seq'::regclass);


--
-- Name: cash_event_items id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_event_items ALTER COLUMN id SET DEFAULT nextval('public.cash_event_items_id_seq'::regclass);


--
-- Name: cash_events id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_events ALTER COLUMN id SET DEFAULT nextval('public.cash_events_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: pending_sales id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.pending_sales ALTER COLUMN id SET DEFAULT nextval('public.pending_sales_id_seq'::regclass);


--
-- Name: product_assembly_templates id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_assembly_templates ALTER COLUMN id SET DEFAULT nextval('public.product_assembly_templates_id_seq'::regclass);


--
-- Name: product_units id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_units ALTER COLUMN id SET DEFAULT nextval('public.product_units_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: purchase_exceptions id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.purchase_exceptions ALTER COLUMN id SET DEFAULT nextval('public.purchase_exceptions_id_seq'::regclass);


--
-- Name: purchase_rules id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.purchase_rules ALTER COLUMN id SET DEFAULT nextval('public.purchase_rules_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.alembic_version (version_num) FROM stdin;
09cf7df8a4fe
\.


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.brands (id, name, description, created_at, updated_at) FROM stdin;
1	forsage	\N	2026-06-21 09:13:48.895809	2026-06-21 09:13:48.895811
2	forcekraft	\N	2026-06-21 10:13:50.59258	2026-06-21 10:13:50.592582
3	arnezi	\N	2026-06-21 10:14:38.928057	2026-06-21 10:14:38.928058
\.


--
-- Data for Name: cash_days; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.cash_days (id, date, is_closed, total_revenue, created_at, updated_at) FROM stdin;
1	2026-06-21 00:00:00	f	0.00	2026-06-21 08:58:36.316554	2026-06-21 08:58:36.316555
\.


--
-- Data for Name: cash_event_items; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.cash_event_items (id, cash_event_id, product_unit_id, price_per_unit, discount_amount, created_at) FROM stdin;
\.


--
-- Data for Name: cash_events; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.cash_events (id, cash_day_id, customer_id, type, total_amount, amount_cash, amount_card, amount_credit, description, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.categories (id, name, parent_id, created_at, updated_at) FROM stdin;
1	ручной_инструмент	\N	2026-06-21 09:02:33.728903	2026-06-21 09:02:33.728905
2	ключи	1	2026-06-21 09:03:00.312198	2026-06-21 09:03:00.3122
3	комбинированные	2	2026-06-21 09:03:11.374072	2026-06-21 09:03:11.374074
4	комбинированные_наборы	2	2026-06-21 09:04:09.492075	2026-06-21 09:04:09.492077
5	накидные	2	2026-06-21 09:04:21.442226	2026-06-21 09:04:21.442227
6	накидные_наборы	2	2026-06-21 09:04:28.538138	2026-06-21 09:04:28.53814
7	свечные	2	2026-06-21 09:04:58.033496	2026-06-21 09:04:58.03352
8	свечные_наборы	2	2026-06-21 09:05:07.984845	2026-06-21 09:05:07.984847
9	е-типа	2	2026-06-21 09:05:40.446584	2026-06-21 09:05:40.446586
10	е-типа_наборы	2	2026-06-21 09:05:46.903364	2026-06-21 09:05:46.903365
11	трещеточные	2	2026-06-21 09:06:32.493385	2026-06-21 09:06:32.493387
12	трещеточные_наборы	2	2026-06-21 09:06:38.90262	2026-06-21 09:06:38.902622
13	радиусные	2	2026-06-21 09:07:45.273598	2026-06-21 09:07:45.273599
14	разводные	2	2026-06-21 09:07:58.23295	2026-06-21 09:07:58.232951
15	разрезные	2	2026-06-21 09:08:09.197864	2026-06-21 09:08:09.197866
16	г-образные_hex_наборы	2	2026-06-21 09:08:19.569069	2026-06-21 09:08:19.56907
17	г-образные_hex	2	2026-06-21 09:08:27.207689	2026-06-21 09:08:27.207691
18	г-образные_torx_наборы	2	2026-06-21 09:08:42.07003	2026-06-21 09:08:42.070032
19	г-образные_torx	2	2026-06-21 09:08:50.640284	2026-06-21 09:08:50.640286
20	газовые_(трубные)	2	2026-06-21 09:09:00.502759	2026-06-21 09:09:00.50276
21	шарнирно-губцевый	1	2026-06-21 10:13:07.85593	2026-06-21 10:13:07.855932
22	клещи/зажимы_для_хомутов	21	2026-06-21 10:13:29.201955	2026-06-21 10:13:29.201956
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.customers (id, name, phone, email, balance, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pending_sales; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.pending_sales (id, cash_day_id, temp_name, temp_price, temp_quantity, temp_category_name, temp_brand_name, status, resolved_product_id, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_assembly_templates; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.product_assembly_templates (id, parent_product_id, child_product_id, quantity) FROM stdin;
\.


--
-- Data for Name: product_units; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.product_units (id, product_id, supplier_id, unique_serial_number, purchase_price, logistics_status, physical_status, is_reserved, parent_unit_id, created_at, updated_at) FROM stdin;
1	5	1	SN-ORD-5F916307	16.70	RECEIVED	IN_STORE	f	\N	2026-06-21 10:17:15.733769	2026-06-21 10:17:28.573746
2	5	1	SN-ORD-A3345DE6	16.70	RECEIVED	IN_STORE	f	\N	2026-06-21 10:17:15.733771	2026-06-21 10:17:28.573746
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.products (id, category_id, brand_id, code, name, description, recommended_retail_price, search_tags, search_aliases, created_at, updated_at, images) FROM stdin;
1	3	1	f-75510h	ключ_комбинированный_10мм,_6гр.	\N	2.01	["ключ", "комбинированный", "10мм", "6гр", "f-75510h", "forsage"]	[]	2026-06-21 09:13:53.010562	2026-06-21 09:13:53.010563	["/assets/hero.png"]
2	4	1	f-5161p-rjs	набор_ключей_комбинированных_16пр.	\N	37.05	["набор", "ключей", "комбинированных", "16пр", "f-5161p-rjs", "forsage"]	[]	2026-06-21 09:15:15.049191	2026-06-21 09:15:15.049192	["/assets/hero.png"]
3	3	1	f-75510	ключ_комбинированный_10мм	\N	2.00	["ключ", "комбинированный", "10мм", "f-75510", "forsage"]	[]	2026-06-21 09:16:28.634671	2026-06-21 09:16:28.634672	["/assets/hero.png"]
4	22	2	fk-62518	клещи_для_снятия_пружинных_хомутов_210мм,_в_блистере	\N	8.82	["клещи", "для", "снятия", "пружинных", "хомутов", "210мм", "блистере", "fk-62518", "forcekraft"]	[]	2026-06-21 10:14:06.749158	2026-06-21 10:14:06.74916	["/assets/hero.png"]
5	22	3	r7703502	клещи_для_самозажимных_хомутов_mubea_arnezi_r7703502	\N	16.68	["клещи", "для", "самозажимных", "хомутов", "mubea", "arnezi", "r7703502", "r7703502", "arnezi"]	[]	2026-06-21 10:14:40.648103	2026-06-21 10:14:40.648104	["/assets/hero.png"]
\.


--
-- Data for Name: purchase_exceptions; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.purchase_exceptions (id, product_id) FROM stdin;
\.


--
-- Data for Name: purchase_rules; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.purchase_rules (id, price_operator, price_value, name_contains, stock_threshold, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: crm_admin
--

COPY public.suppliers (id, name, contact_info, created_at, updated_at) FROM stdin;
1	Армтек	\N	2026-06-21 10:16:31.427256	2026-06-21 10:16:31.427257
\.


--
-- Name: brands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.brands_id_seq', 3, true);


--
-- Name: cash_days_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.cash_days_id_seq', 1, true);


--
-- Name: cash_event_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.cash_event_items_id_seq', 1, false);


--
-- Name: cash_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.cash_events_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.categories_id_seq', 22, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: pending_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.pending_sales_id_seq', 1, false);


--
-- Name: product_assembly_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.product_assembly_templates_id_seq', 1, false);


--
-- Name: product_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.product_units_id_seq', 2, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.products_id_seq', 5, true);


--
-- Name: purchase_exceptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.purchase_exceptions_id_seq', 1, false);


--
-- Name: purchase_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.purchase_rules_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_admin
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: cash_days cash_days_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_days
    ADD CONSTRAINT cash_days_pkey PRIMARY KEY (id);


--
-- Name: cash_event_items cash_event_items_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_event_items
    ADD CONSTRAINT cash_event_items_pkey PRIMARY KEY (id);


--
-- Name: cash_events cash_events_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_events
    ADD CONSTRAINT cash_events_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: pending_sales pending_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.pending_sales
    ADD CONSTRAINT pending_sales_pkey PRIMARY KEY (id);


--
-- Name: product_assembly_templates product_assembly_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_assembly_templates
    ADD CONSTRAINT product_assembly_templates_pkey PRIMARY KEY (id);


--
-- Name: product_units product_units_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_units
    ADD CONSTRAINT product_units_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_exceptions purchase_exceptions_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.purchase_exceptions
    ADD CONSTRAINT purchase_exceptions_pkey PRIMARY KEY (id);


--
-- Name: purchase_exceptions purchase_exceptions_product_id_key; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.purchase_exceptions
    ADD CONSTRAINT purchase_exceptions_product_id_key UNIQUE (product_id);


--
-- Name: purchase_rules purchase_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.purchase_rules
    ADD CONSTRAINT purchase_rules_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: ix_brands_name; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE UNIQUE INDEX ix_brands_name ON public.brands USING btree (name);


--
-- Name: ix_cash_days_date; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE UNIQUE INDEX ix_cash_days_date ON public.cash_days USING btree (date);


--
-- Name: ix_customers_name; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE INDEX ix_customers_name ON public.customers USING btree (name);


--
-- Name: ix_customers_phone; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE UNIQUE INDEX ix_customers_phone ON public.customers USING btree (phone);


--
-- Name: ix_product_units_unique_serial_number; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE UNIQUE INDEX ix_product_units_unique_serial_number ON public.product_units USING btree (unique_serial_number);


--
-- Name: ix_products_code; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE UNIQUE INDEX ix_products_code ON public.products USING btree (code);


--
-- Name: ix_purchase_exceptions_id; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE INDEX ix_purchase_exceptions_id ON public.purchase_exceptions USING btree (id);


--
-- Name: ix_purchase_rules_id; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE INDEX ix_purchase_rules_id ON public.purchase_rules USING btree (id);


--
-- Name: ix_suppliers_name; Type: INDEX; Schema: public; Owner: crm_admin
--

CREATE UNIQUE INDEX ix_suppliers_name ON public.suppliers USING btree (name);


--
-- Name: cash_event_items cash_event_items_cash_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_event_items
    ADD CONSTRAINT cash_event_items_cash_event_id_fkey FOREIGN KEY (cash_event_id) REFERENCES public.cash_events(id);


--
-- Name: cash_event_items cash_event_items_product_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_event_items
    ADD CONSTRAINT cash_event_items_product_unit_id_fkey FOREIGN KEY (product_unit_id) REFERENCES public.product_units(id);


--
-- Name: cash_events cash_events_cash_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_events
    ADD CONSTRAINT cash_events_cash_day_id_fkey FOREIGN KEY (cash_day_id) REFERENCES public.cash_days(id);


--
-- Name: cash_events cash_events_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.cash_events
    ADD CONSTRAINT cash_events_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: categories categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- Name: pending_sales pending_sales_cash_day_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.pending_sales
    ADD CONSTRAINT pending_sales_cash_day_id_fkey FOREIGN KEY (cash_day_id) REFERENCES public.cash_days(id);


--
-- Name: pending_sales pending_sales_resolved_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.pending_sales
    ADD CONSTRAINT pending_sales_resolved_product_id_fkey FOREIGN KEY (resolved_product_id) REFERENCES public.products(id);


--
-- Name: product_assembly_templates product_assembly_templates_child_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_assembly_templates
    ADD CONSTRAINT product_assembly_templates_child_product_id_fkey FOREIGN KEY (child_product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_assembly_templates product_assembly_templates_parent_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_assembly_templates
    ADD CONSTRAINT product_assembly_templates_parent_product_id_fkey FOREIGN KEY (parent_product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_units product_units_parent_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_units
    ADD CONSTRAINT product_units_parent_unit_id_fkey FOREIGN KEY (parent_unit_id) REFERENCES public.product_units(id);


--
-- Name: product_units product_units_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_units
    ADD CONSTRAINT product_units_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: product_units product_units_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.product_units
    ADD CONSTRAINT product_units_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: products products_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brands(id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: purchase_exceptions purchase_exceptions_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_admin
--

ALTER TABLE ONLY public.purchase_exceptions
    ADD CONSTRAINT purchase_exceptions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict uup1ieCnGictJenlzSh5bK7Qd6GwXshvLV0WcWgQB8UJV2wMbuseFTXDKEBX92u

